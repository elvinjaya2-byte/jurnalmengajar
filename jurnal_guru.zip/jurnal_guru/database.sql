CREATE DATABASE IF NOT EXISTS jurnal_guru CHARACTER SET utf8mb4;
USE jurnal_guru;
CREATE TABLE IF NOT EXISTS users(
 id INT AUTO_INCREMENT PRIMARY KEY, nama VARCHAR(100) NOT NULL,
 email VARCHAR(100) NOT NULL UNIQUE, password VARCHAR(255) NOT NULL,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS jurnal(
 id INT AUTO_INCREMENT PRIMARY KEY, user_id INT NOT NULL,
 mapel VARCHAR(100), materi_pokok VARCHAR(150), sub_materi VARCHAR(150), tanggal DATE, kelas VARCHAR(30),
 semester VARCHAR(20), pertemuan VARCHAR(10), jam VARCHAR(30), tahun VARCHAR(20),
 cp TEXT, tujuan TEXT, pendahuluan TEXT, inti TEXT, penutup TEXT,
 total INT DEFAULT 0, hadir INT DEFAULT 0, sakit INT DEFAULT 0, izin INT DEFAULT 0, alpa INT DEFAULT 0,
 respon TEXT, n_pengetahuan TEXT, n_keterampilan TEXT, n_sikap TEXT,
 masalah TEXT, tindak_lanjut TEXT, tugas TEXT, media TEXT,
 ref_baik TEXT, ref_perbaiki TEXT, ref_rencana TEXT, catatan TEXT,
 created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE);
