<?php require 'config.php';need();
$id=(int)($_GET['id']??0);$copy=(int)($_GET['copy']??0);$d=array_fill_keys(array_keys($F),'');
if($id||$copy){$s=$pdo->prepare('SELECT * FROM jurnal WHERE id=? AND user_id=?');$s->execute([$id?:$copy,$_SESSION['uid']]);
 $d=$s->fetch()?:$d;if($copy){$d['tanggal']=date('Y-m-d');$d['pertemuan']=(string)((int)$d['pertemuan']+1);foreach(['keaktifan','respon','masalah','tindak_lanjut','tugas','ref_baik','ref_perbaiki','ref_rencana','catatan','hadir','sakit','izin','alpa'] as $k)$d[$k]='';}}
if(!$d['nama_guru'])$d['nama_guru']=$_SESSION['nama'];
if($_SERVER['REQUEST_METHOD']=='POST'){
 $v=[];foreach($F as $k=>$f){$x=$_POST[$k]??'';if(is_array($x))$x=implode(', ',$x);$x=trim($x);
  $v[$k]=$x!==''?$x:($f[1]=='number'?0:($f[1]=='date'?null:''));}
 if($id){$set=implode(',',array_map(fn($k)=>"$k=?",array_keys($F)));
  $pdo->prepare("UPDATE jurnal SET $set WHERE id=? AND user_id=?")->execute([...array_values($v),$id,$_SESSION['uid']]);$pid=$id;}
 else{$cols=implode(',',array_keys($F));$q=implode(',',array_fill(0,count($F),'?'));
  $pdo->prepare("INSERT INTO jurnal(user_id,$cols) VALUES(?,$q)")->execute([$_SESSION['uid'],...array_values($v)]);$pid=$pdo->lastInsertId();}
 header("Location: print.php?id=$pid");exit;}
$g='';
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Form Jurnal</title><link rel="stylesheet" href="style.css"></head><body>
<header class="top"><b>📘 Jurnal Mengajar</b><span><a href="index.php">← Kembali</a></span></header>
<main><h2><?=$id?'Edit':'Buat'?> Jurnal</h2><form method="post">
<?php foreach($F as $k=>$f):
 if($f[2]!=$g){if($g)echo '</div></div>';$g=$f[2];echo '<div class="card"><h3>'.e($g).'</h3><div class="grid">';}
 if($f[1]=='radio'||$f[1]=='check'):
  $chk=$f[1]=='check';$sel=$chk?array_map('trim',explode(',',$d[$k])):[$d[$k]];?>
  <div class="full"><span class="lb"><?=e($f[0])?></span><div class="opts">
  <?php foreach($OPT[$k] as $o):?><label class="chip"><input type="<?=$chk?'checkbox':'radio'?>" name="<?=$k.($chk?'[]':'')?>" value="<?=e($o)?>" <?=in_array($o,$sel)?'checked':''?>> <?=e($o)?></label><?php endforeach;?>
  </div></div>
 <?php else:?>
  <label class="<?=$f[1]=='area'?'full':''?>"><?=e($f[0])?>
  <?php if($f[1]=='area'):?><textarea name="<?=$k?>" rows="3"><?=e($d[$k])?></textarea>
  <?php else:?><input type="<?=$f[1]?>" name="<?=$k?>" value="<?=e($d[$k])?>"><?php endif;?></label>
 <?php endif;endforeach;?></div></div>
<div class="bar"><span></span><button class="btn">💾 Simpan & Lihat Hasil Cetak</button></div></form></main></body></html>
