<?php require 'config.php';
$daftar=isset($_GET['daftar']);$err='';
if($_SERVER['REQUEST_METHOD']=='POST'){
 $em=trim($_POST['email']);$pw=$_POST['password'];
 if($daftar){
  $n=trim($_POST['nama']);
  if(!$n||!filter_var($em,FILTER_VALIDATE_EMAIL)||strlen($pw)<6)$err='Isi semua data dengan benar (password min. 6 karakter).';
  else{$c=$pdo->prepare('SELECT 1 FROM users WHERE email=?');$c->execute([$em]);
   if($c->fetch())$err='Email sudah terdaftar.';
   else{$pdo->prepare('INSERT INTO users(nama,email,password) VALUES(?,?,?)')->execute([$n,$em,password_hash($pw,PASSWORD_DEFAULT)]);
    header('Location: login.php?ok=1');exit;}}
 }else{
  $s=$pdo->prepare('SELECT * FROM users WHERE email=?');$s->execute([$em]);$u=$s->fetch();
  if($u&&password_verify($pw,$u['password'])){session_regenerate_id(true);$_SESSION['uid']=$u['id'];$_SESSION['nama']=$u['nama'];header('Location: index.php');exit;}
  $err='Email atau password salah.';
 }}
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=$daftar?'Daftar':'Masuk'?> - Jurnal Guru</title><link rel="stylesheet" href="style.css"></head>
<body class="auth"><form method="post" class="card login">
<div class="logo">📘</div><h1>Jurnal Mengajar Harian</h1><p class="muted"><?=$daftar?'Buat akun guru baru':'Masuk untuk mengisi jurnal Anda'?></p>
<?php if($err):?><div class="alert"><?=e($err)?></div><?php endif;?>
<?php if(isset($_GET['ok'])):?><div class="alert ok">Pendaftaran berhasil, silakan masuk.</div><?php endif;?>
<?php if($daftar):?><label>Nama Lengkap<input name="nama" required></label><?php endif;?>
<label>Email<input type="email" name="email" required></label>
<label>Password<input type="password" name="password" required></label>
<button class="btn"><?=$daftar?'Daftar':'Masuk'?></button>
<p class="muted"><?=$daftar?'Sudah punya akun? <a href="login.php">Masuk</a>':'Belum punya akun? <a href="login.php?daftar=1">Daftar</a>'?></p>
</form></body></html>
