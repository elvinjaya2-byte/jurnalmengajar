<?php
session_start();
$opt=[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC];
try{
 $pdo=new PDO('mysql:host=localhost;charset=utf8mb4','root','',$opt); // ganti user/password jika perlu
 $pdo->exec('CREATE DATABASE IF NOT EXISTS jurnal_guru CHARACTER SET utf8mb4');
 $pdo->exec('USE jurnal_guru');
 // Buat tabel otomatis jika belum ada
 if(!$pdo->query("SHOW TABLES LIKE 'jurnal'")->fetch()) $pdo->exec(file_get_contents(__DIR__.'/database.sql'));
// Tambah kolom baru otomatis jika belum ada (untuk database lama)
 foreach(['keaktifan'=>'VARCHAR(30)','media_pilih'=>'VARCHAR(255)','media_lain'=>'VARCHAR(100)','nama_guru'=>'VARCHAR(100)','nip_guru'=>'VARCHAR(40)','nama_kepsek'=>'VARCHAR(100)','nip_kepsek'=>'VARCHAR(40)'] as $c=>$t)
  if(!$pdo->query("SHOW COLUMNS FROM jurnal LIKE '$c'")->fetch())$pdo->exec("ALTER TABLE jurnal ADD $c $t");
}catch(PDOException $x){die('Koneksi database gagal: '.htmlspecialchars($x->getMessage()).'<br>Pastikan MySQL di XAMPP sudah Start dan user/password di config.php benar.');}
function e($s){return htmlspecialchars((string)$s,ENT_QUOTES,'UTF-8');}
function need(){if(empty($_SESSION['uid'])){header('Location: login.php');exit;}}
function hari($d){$h=['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];return $d?$h[date('w',strtotime($d))].', '.date('d-m-Y',strtotime($d)):'';}
$OPT=['keaktifan'=>['Sangat Aktif','Aktif','Cukup Aktif','Kurang Aktif'],
'media_pilih'=>['Buku','PPT / Slide','Video','LKPD','Internet','AI / ChatGPT','Canva','Alat Peraga','Lainnya']];
// key => [label, tipe, grup]
$I='Identitas';$T='Capaian & Tujuan Pembelajaran';$K='Kegiatan Pembelajaran';$H='Kehadiran Siswa';$R='Respon Siswa';
$P='Penilaian dan Evaluasi';$M='Permasalahan & Tindak Lanjut';$U='Tugas & Media Pembelajaran';$RF='Refleksi Guru';$G='Pengesahan';
$F=[
'mapel'=>['Mata Pelajaran','text',$I],'materi_pokok'=>['Materi Pokok','text',$I],'sub_materi'=>['Sub Materi','text',$I],
'tanggal'=>['Tanggal','date',$I],'kelas'=>['Kelas','text',$I],'semester'=>['Semester','text',$I],
'pertemuan'=>['Pertemuan Ke','text',$I],'jam'=>['Jam Pelajaran','text',$I],'tahun'=>['Tahun Pelajaran','text',$I],
'cp'=>['Capaian Pembelajaran (CP)','area',$T],'tujuan'=>['Tujuan Pembelajaran','area',$T],
'pendahuluan'=>['Pendahuluan','area',$K],'inti'=>['Kegiatan Inti','area',$K],'penutup'=>['Penutup','area',$K],
'total'=>['Jumlah Seluruh Siswa','number',$H],'hadir'=>['Hadir','number',$H],'sakit'=>['Sakit','number',$H],
'izin'=>['Izin','number',$H],'alpa'=>['Tanpa Keterangan','number',$H],
'keaktifan'=>['Tingkat Keaktifan','radio',$R],'respon'=>['Catatan','area',$R],
'n_pengetahuan'=>['Pengetahuan','area',$P],'n_keterampilan'=>['Keterampilan','area',$P],'n_sikap'=>['Sikap','area',$P],
'masalah'=>['Permasalahan selama KBM','area',$M],'tindak_lanjut'=>['Perbaikan / Tindak Lanjut','area',$M],
'tugas'=>['Tugas / PR','area',$U],'media_pilih'=>['Media Pembelajaran','check',$U],'media_lain'=>['Media lainnya (sebutkan)','text',$U],
'ref_baik'=>['Hal yang berjalan dengan baik','area',$RF],'ref_perbaiki'=>['Hal yang perlu diperbaiki','area',$RF],
'ref_rencana'=>['Rencana untuk pembelajaran berikutnya','area',$RF],'catatan'=>['Catatan Tambahan','area',$RF],
'nama_guru'=>['Nama Guru Mata Pelajaran','text',$G],'nip_guru'=>['NIP Guru','text',$G],
'nama_kepsek'=>['Nama Kepala Sekolah','text',$G],'nip_kepsek'=>['NIP Kepala Sekolah','text',$G],
];
