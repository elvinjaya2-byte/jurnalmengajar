<?php require 'config.php';need();
$s=$pdo->prepare('SELECT * FROM jurnal WHERE id=? AND user_id=?');$s->execute([(int)$_GET['id'],$_SESSION['uid']]);
$d=$s->fetch();if(!$d)die('Data tidak ditemukan');
$media=str_replace('Lainnya','Lainnya'.($d['media_lain']?': '.$d['media_lain']:''),$d['media_pilih']);
$nmg=$d['nama_guru']?:$_SESSION['nama'];
function b($t,$c,$cls=''){echo "<section class='bx $cls'><h4>".e($t)."</h4><div>".nl2br(e($c))."</div></section>";}
?><!doctype html><html lang="id"><head><meta charset="utf-8"><title>Jurnal <?=e($d['tanggal'])?></title>
<link rel="stylesheet" href="style.css"></head><body class="pv">
<div class="noprint bar" style="max-width:210mm;margin:10px auto"><a class="btn ghost" href="index.php">← Dashboard</a>
<span><a class="btn ghost" href="form.php?id=<?=$d['id']?>">✏ Edit</a> <button class="btn" onclick="print()">🖨 Cetak / Simpan PDF</button></span></div>
<div class="page"><div class="ph"><h1>JURNAL MENGAJAR HARIAN GURU</h1><span class="rib">Dokumentasi Pembelajaran</span></div>
<div class="info"><div>
<p><i>Mata Pelajaran</i>: <?=e($d['mapel'])?></p><p><i>Materi Pokok</i>: <?=e($d['materi_pokok'])?></p><p><i>Sub Materi</i>: <?=e($d['sub_materi'])?></p>
<p><i>Hari / Tanggal</i>: <?=e(hari($d['tanggal']))?></p><p><i>Kelas</i>: <?=e($d['kelas'])?></p></div><div>
<p><i>Semester</i>: <?=e($d['semester'])?></p><p><i>Pertemuan Ke</i>: <?=e($d['pertemuan'])?></p><p><i>Jam Pelajaran</i>: <?=e($d['jam'])?></p>
<p><i>Tahun Pelajaran</i>: <?=e($d['tahun'])?></p><p><i>Guru</i>: <?=e($nmg)?></p></div></div>
<div class="r2"><?php b('CAPAIAN PEMBELAJARAN (CP)',$d['cp']);b('TUJUAN PEMBELAJARAN',$d['tujuan'],'gr');?></div>
<div class="r2"><section class="bx big"><h4>KEGIATAN PEMBELAJARAN</h4>
<b>1. Pendahuluan</b><div><?=nl2br(e($d['pendahuluan']))?></div><b>2. Kegiatan Inti</b><div><?=nl2br(e($d['inti']))?></div><b>3. Penutup</b><div><?=nl2br(e($d['penutup']))?></div></section>
<div class="col"><section class="bx"><h4>KEHADIRAN SISWA</h4><table class="t"><tr><th>Keterangan</th><th>Jumlah Siswa</th></tr>
<tr><td>Jumlah Seluruh Siswa</td><td><?=$d['total']?></td></tr><tr><td>Hadir</td><td><?=$d['hadir']?></td></tr><tr><td>Sakit</td><td><?=$d['sakit']?></td></tr>
<tr><td>Izin</td><td><?=$d['izin']?></td></tr><tr><td>Tanpa Keterangan</td><td><?=$d['alpa']?></td></tr></table></section>
<?php b('RESPON SISWA',($d['keaktifan']?'Tingkat keaktifan: '.$d['keaktifan']:'').($d['respon']?"\n".$d['respon']:''),'dash grow');?></div></div>
<div class="r3"><section class="bx"><h4>PENILAIAN DAN EVALUASI</h4><b>a. Pengetahuan</b><div><?=nl2br(e($d['n_pengetahuan']))?></div>
<b>b. Keterampilan</b><div><?=nl2br(e($d['n_keterampilan']))?></div><b>c. Sikap</b><div><?=nl2br(e($d['n_sikap']))?></div></section>
<?php b('PERMASALAHAN SELAMA KBM',$d['masalah']);b('PERBAIKAN / TINDAK LANJUT',$d['tindak_lanjut']);?></div>
<div class="r3"><?php b('TUGAS / PR',$d['tugas']);b('MEDIA PEMBELAJARAN',$media,'dash');?>
<section class="bx"><h4>REFLEKSI GURU</h4><b>Hal yang berjalan dengan baik</b><div><?=nl2br(e($d['ref_baik']))?></div>
<b>Hal yang perlu diperbaiki</b><div><?=nl2br(e($d['ref_perbaiki']))?></div><b>Rencana untuk pembelajaran berikutnya</b><div><?=nl2br(e($d['ref_rencana']))?></div></section></div>
<?php b('CATATAN',$d['catatan'],'note');?>
<div class="ttd"><div><p>Mengetahui,<br>Kepala Sekolah</p><u><b><?=e($d['nama_kepsek'])?></b></u><br><?=$d['nip_kepsek']?'NIP. '.e($d['nip_kepsek']):''?></div>
<div><p><?=e($d['tanggal']?date('d-m-Y',strtotime($d['tanggal'])):'')?><br>Guru Mata Pelajaran</p><u><b><?=e($nmg)?></b></u><br><?=$d['nip_guru']?'NIP. '.e($d['nip_guru']):''?></div></div>
<p class="quote">“Mengajar adalah menyalakan api, <b>bukan mengisi bejana.</b>”</p></div></body></html>
