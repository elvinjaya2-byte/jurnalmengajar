<?php require 'config.php';need();
if($_SERVER['REQUEST_METHOD']=='POST'&&isset($_POST['hapus'])){
 $pdo->prepare('DELETE FROM jurnal WHERE id=? AND user_id=?')->execute([$_POST['hapus'],$_SESSION['uid']]);header('Location: index.php');exit;}
$s=$pdo->prepare('SELECT id,tanggal,mapel,kelas,pertemuan,sub_materi FROM jurnal WHERE user_id=? ORDER BY tanggal DESC,id DESC');
$s->execute([$_SESSION['uid']]);$rows=$s->fetchAll();
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Dashboard - Jurnal Guru</title><link rel="stylesheet" href="style.css"></head><body>
<header class="top"><b>📘 Jurnal Mengajar</b><span>Halo, <?=e($_SESSION['nama'])?> · <a href="logout.php">Keluar</a></span></header>
<main><div class="bar"><div><h2>Daftar Jurnal</h2><p class="muted"><?=count($rows)?> jurnal tersimpan</p></div>
<a class="btn" href="form.php">+ Buat Jurnal Baru</a></div>
<div class="card"><?php if(!$rows):?><p class="muted center">Belum ada jurnal. Klik "Buat Jurnal Baru" untuk memulai.</p><?php else:?>
<div class="scroll"><table><tr><th>Tanggal</th><th>Mapel</th><th>Kelas</th><th>Pert.</th><th>Sub Materi</th><th>Aksi</th></tr>
<?php foreach($rows as $r):?><tr><td><?=e(hari($r['tanggal']))?></td><td><?=e($r['mapel'])?></td><td><?=e($r['kelas'])?></td><td><?=e($r['pertemuan'])?></td><td><?=e($r['sub_materi'])?></td>
<td class="act"><a href="print.php?id=<?=$r['id']?>" target="_blank">🖨 Cetak</a><a href="form.php?id=<?=$r['id']?>">✏ Edit</a><a href="form.php?copy=<?=$r['id']?>">⧉ Duplikat</a>
<form method="post" onsubmit="return confirm('Hapus jurnal ini?')"><button name="hapus" value="<?=$r['id']?>" class="del">🗑</button></form></td></tr><?php endforeach;?></table></div><?php endif;?></div>
<p class="muted center">Tips: gunakan <b>Duplikat</b> agar CP, tujuan, dan identitas tidak perlu diketik ulang.</p></main></body></html>
